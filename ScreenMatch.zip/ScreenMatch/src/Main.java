public class Main {
    public static void main(String[] args) {
        System.out.println("Esse é o Screen Match");
        System.out.println("Filme: Top Gun: Maverick");

        int anoDeLancamento = 2022;
        System.out.println("Ano de lançamento: " + anoDeLancamento);
        boolean incluidoNoPlano = true;
        double notaDoFilme =  8.1;
        System.out.println("Está incluido no plano do filme: " + incluidoNoPlano);
        System.out.println("A nota do filme:" + notaDoFilme);

        String sinopse = "Filme de aventura";
        System.out.println(sinopse);
    }
}