import java.util.Scanner;

public class Desafio {
    public static void main(String[] args) {
        String nome = "Adrielson Pinheiro";
        String tipoConta = "Corrente";
        double saldo = 1600.99;
        int option = 0;

        System.out.println("****************************************");
        System.out.println("\n Nome do cliente: "+ nome);
        System.out.println("\n Tipo Conta: "+ tipoConta);
        System.out.println("\n Saldo atual: "+ saldo);
        System.out.println("\n****************************************");


        String menu = """
                ** Digite sua opção **
                1 - Consultar saldo
                2 - Transferir valor
                3 - Depositar valor
                4 - Sair
                
                
                """;
        Scanner leitura = new Scanner(System.in);

        while (option != 4) {
            System.out.println(menu);
            option = leitura.nextInt();


            if (option == 1) {
                System.out.println("\n Saldo atual: "+ saldo);
            }
            else if (option == 2) {
                System.out.println("Qual o valor que deseja transferir? ");
                double valor = leitura.nextDouble();
                if (valor > saldo) {
                    System.out.println("Não é possivel realizar a operação. Se torne mais rico para isso");
                } else {
                    saldo = saldo - valor;
                    System.out.println("Sucesso! Transferido " + valor + "reais");
                    System.out.println("Seu novo saldo é: " + saldo);
                }
            }
            else if (option == 3) {
                System.out.println("Qual o valor que deseja depositar? ");
                double valor = leitura.nextDouble();
                saldo += valor;
                System.out.println("Sucesso! Depositado " + valor + "reais");
                System.out.println("Seu novo saldo é: " + saldo);
            }
            else if (option != 4) {
                System.out.println("Opção Invalida!!!");
            }
        }



    }


}
