public class Condicional {
    public static void main(String[] args) {
        int anoDeLancamento = 2022;
        boolean incluidoNoPlano = true;
        double notaDoFilme =  8.1;

        if (anoDeLancamento > 2022) {
            System.out.println("Lançamentos recentes");
        } else {
            System.out.println("Filme retrô");
        }

    }
}
